import React, { Component, useState } from 'react'
import {
  View,
  Text,
  Image,
  Button,
} from 'react-native';
import { connect } from "react-redux";
import { changeState, returnState } from "../redux/actions";
import { styles } from '../styles';

let serverImg = [];

const getImg = async () => {
  const response = await fetch('https://imagesapi.osora.ru/', {
    method: 'GET'
  });

  const result = await response.json();
  serverImg = result;

  // for (i = 0; i < result.length; i++) {
  //   serverImg.push(require(`${result[i]}`))
  // }
}

getImg();

const mapStateToProps = (state) => ({
  state: state,
});

const mapDispatchToProps = (dispatch) => {
  return {
    changeState: (urls) => dispatch(changeState(urls)),
    returnState: () => dispatch({type: 'INIT'}),
  }
};

class SliderList extends Component {
  constructor(props){
    super(props)
  }

  render() {
      // let [count, setCount] = useState(0);

      // const nextImg = () => {
      //   (count++ === props.img.length-1) ? setCount(0) : setCount(count++);
      // }

      // const prevImg = () => {
      //   (count-- === 0) ? setCount(props.img.length-1) : setCount(count--);
      // }

    return (
      <View style={styles.slider__list}>
        <Button title="prev" />
        <Button title="switch" onPress={this.props.func} />
        <Button title="next" />
        <SliderItem img={this.props.img[0]} />
      </View>
    )
  }
}

class SliderItem extends Component {
  constructor(props){
    super(props)
  }

  render() {
    return (
      <View style={styles.slider__item}>
        <Image source={{uri: this.props.img}} style={styles.slider__img} />
      </View>
    )
  }
}

class SliderPage extends Component {
  constructor(props){
    super(props);
  }

  render() {
    return (
      <View>
        {/* <SliderList func={() => {
          (this.props.state.isLocal) ? this.props.changeState(serverImg) : this.props.returnState()
          // this.props.changeState(serverImg)
          console.log(this.props)
        }} img={this.props.state.src} state={this.props.state.isLocal}/> */}
        <Button title='title' onPress={() => { 
          if (this.props.state.isLocal === true) {
            this.props.changeState(serverImg)
          } else if (this.props.state.isLocal === false) {
            this.props.returnState();
          }
          console.log(this.props.state.isLocal) }} />
      </View>
    )
  }
}

export default connect(mapStateToProps, mapDispatchToProps)(SliderPage);
