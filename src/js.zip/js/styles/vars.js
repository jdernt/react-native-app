import React from "react";

export const styleVars = {
	mainBg: '#fff',
	darkBg: '#333',
	lightFont: '#ededed',
	dargFont: '#333',
	fontFamily: 'monospace',
}