import { CHANGE_STATE, RETURN_STATE } from './actionTypes';

import slide1 from '../../img/photo-1.jpg';
import slide2 from '../../img/photo-2.jpg';
import slide3 from '../../img/photo-3.jpg';

const initialState = {
  isLocal: true,
  src: [require('../../img/photo-3.jpg'), require('../../img/photo-2.jpg'), require('../../img/photo-1.jpg')]
};

// const initialState = {
//   isLocal: true,
//   src: ['../../img/photo-3.jpg', '../../img/photo-2.jpg', '../../img/photo-1.jpg']
// };

export default function (state = initialState, action) {
  // switch (action.type) {
  //   case CHANGE_STATE: {
  //     return {
  //       ...state,
  //       isLocal: false,
  //       src: action.src,
  //     };
  //   }
  //   // case RETURN_STATE: {
  //   //   return {
  //   //     ...state,
  //   //     isLocal: true,
  //   //     src: state.src
  //   //   }
  //   // }
  //   default: 
  //     return state;
  // } 
  if (action.type === CHANGE_STATE) {
    return {
      ...state,
      isLocal: false,
      src: action.src,
    };
  } else {
    return state;
  }
}